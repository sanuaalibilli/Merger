#import ms.version
import os

#ms.version.addpkg("numpy","1.11.0")
#ms.version.addpkg("pytz","2014.10")
#ms.version.addpkg("dateutil","2.5.2")

#args -M : Mappings File
#args -A : Aliases File
#args -F : FileToProcess
#args -D : DataSetName
#args -B : BusinessDate
#args -C : ConfigFile

import argparse
import logging

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'Recon Merger Script for Merging the Individual Recon Files')
    parser.add_argument('-O','--OutFileName',help="Outfile Name", required = True)
    parser.add_argument('-P','--Prefix',help="Input files Prefix",required = True)
    parser.add_argument('-B','--BusinessDate',help="BusinessDate",required = True)
    parser.add_argument('-L','--LoggingLevel',choices=['DEBUG', 'INFO', 'WARNING','ERROR'],help="LoggingLevel",required = True)
    
    # python Merger.py -O Reconer_Merged_File.dat -P RECON_ -B 20200610 -L INFO
    args = vars(parser.parse_args())
    print("Args are %s",args)
    
outFileName = args['OutFileName']
infile_prefix = args['Prefix']
businessDate = args['BusinessDate']
logLevel = args['LoggingLevel']
outFileDirectory = 'D:\\tempDir\\Output_Files'

def getCustomLogger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logLevel)
    c_handler = logging.StreamHandler()
    f_handler = logging.FileHandler("diagnostic.log", 'w')
    c_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
    f_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
    logger.addHandler(c_handler)
    logger.addHandler(f_handler)
    c_handler.setFormatter(c_format)
    f_handler.setFormatter(f_format)
    return logger

logger = getCustomLogger("Merger")
logger.info("Args are %s",args)

def getFilesForMerge(outFileDirectory):
    files = []
    for file in os.listdir(outFileDirectory):
        logger.debug(os.path.join(outFileDirectory,file))
        files.append(os.path.join(outFileDirectory,file))
    return files

ReconFiles = getFilesForMerge(outFileDirectory)
header = False
openMergedOutFile = open(os.path.join(outFileDirectory,outFileName),'w')
ind_File_Line_Counter = 0
over_all_File_Line_Counter = 0
for file in ReconFiles:
    if str(file).find(infile_prefix) > -1:
        if str(file).find(businessDate) > -1:
            logger.info('File of Interest is %s',file)
            openInfile = open(file,'r')
            ind_File_Line_Counter = 0
            while True:
                line = openInfile.readline()
                if not line: 
                    break
                
                strLine = line.strip()
                if str(strLine).startswith('BusinessDate'):
                    if not header:
                        logger.info('Writing Header to FinalOutFile...')
                        openMergedOutFile.write(strLine+"\n")
                        header = True
                else:
                    openMergedOutFile.write(strLine+"\n")
                    ind_File_Line_Counter = ind_File_Line_Counter + 1
                    
            openInfile.close()
            logger.info('Current File : %s : Read: %s Lines',file,ind_File_Line_Counter)
            over_all_File_Line_Counter = over_all_File_Line_Counter + ind_File_Line_Counter
            logger.info('Current OutFile is %s Line Count : %s',os.path.join(outFileDirectory,outFileName),over_all_File_Line_Counter)
            
openMergedOutFile.close()
